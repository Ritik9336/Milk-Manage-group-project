This is a [Next.js](https://nextjs.org/) project bootstrapped with [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app).

## Getting Started

First, Install the dependencies by running the following command

```bash
npm install
```
Create a mysql database 

```bash
CREATE DATABASE diaryhelp;
```
Update the database name and credentials in the db.js in the lib folder.

Now you can run server using the following command

```bash
npm run dev
```

## Optional Changes
This code requires some changes so we can skip showing errors like unable to fetch data from the database for the new user.
new tables are genrated by the email address to keep the data seperate.

You can move some code to the try catch block. On the pages/dashboard or set the default values using conditions.

# Steps
1. Create account 
2. insert daily price for every combinations. ( to skip some errors on the dashboard page)
3. Add Customers
4. Add Expense items.
5. Insert Milk Entries
6. Print Bills 
